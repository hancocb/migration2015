Written by Youn Shik Park

GA_STEPL.f		| Genetic Algorithm to calibrate STEPL parameters
			| f77 GA_STEPL.f
STEPL_0613.f		| STEPL ver. 2013-06-13
			| f90 STEPL_0613.f
AMC_STEPL.f		| Automated Manual Calibration Algorithm to calibrate STEPL parameters
			| f90 AMC_STEPL.f
STEPL4AMC.f		| STEPL ver. 2013-06-13 for AMC_STEPL.f
			| f90 STEPL4AMC.f


